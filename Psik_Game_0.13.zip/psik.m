%Volani funkci pro start hry

loadSkins();
createStartScreen();


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Definice Premennych
%premenne pre hrdinu
global hero;
global heroSize;
global playerHandle;
%premenna pre granulku
global target;

global numWins;
numWins = 0;
%Premenne pre sledovanie skore a ukoncenie hry
global score;
score = 0;
global isGameOver;

%Premenne na zvolenie obrazku pre hraca
global skins;
global selectedSkin;

%Hracia plocha - Premenne
global gameFig;
global scoreText;

%Premenne pre zly bodik, nastavenie rychlosti pohybu
global badPoint;
global moveDistance;
moveDistance = 5;

global audioPlayer;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Nacitanie obrazku hraca

function loadSkins()
    global selectedSkin;
    skins = struct();
    skins.default = imread('pes.png');
    skins.skin1 = imread('dog_iny.png');
    selectedSkin = 'pes.png';
end

function updateWins()
    global numWins;
    numWins = numWins + 1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Menu na vyberanie skinu hraca
function createSkinSelectionMenu()
    global numWins;
    % Vytvorenie menu pre zvolenie skinu
    skinSelectionFig = figure('Color', 'white', 'NumberTitle', 'off', 'MenuBar', 'none', ...
                              'Name', 'Select Your Skin', 'Position', [100, 100, 300, 200]);
    %podmienky pre skiny
    enableSkin1 = 'off';
    if numWins >= 1  %Podmienka kolko vyhier treba, aby hrac si mohol dat dany skin
        enableSkin1 = 'on';
    end
    
    % Default Skin Button
    uicontrol('Style', 'pushbutton', 'String', 'Default Skin', ...
              'Position', [50, 150, 200, 40], 'Callback', {@setSkin, 'pes.png'});
    
    % Skin 1 Button
    uicontrol('Style', 'pushbutton', 'String', 'Skin 1 - 5 vyhier', ...
              'Position', [50, 100, 200, 40], 'Enable', enableSkin1, ...
              'Callback', {@setSkin, 'dog_iny.png'});

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%setnutie skinu
function setSkin(source, event, skinFileName)
    global selectedSkin;
    selectedSkin = skinFileName;
    close(ancestor(source, 'figure')); 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Vytvorenie startovacej obrazovky
function createStartScreen()
    global numWins;

    % Vytvorenie figure pre start menu
    startFig = figure('Color', 'white', 'NumberTitle', 'off', 'MenuBar', 'none', ...
                      'Name', 'Game Menu', 'Position', [100, 100, 300, 300]);
    % Obrazek v pozadi
    ax = axes('Units', 'normalized', 'Position', [0 0 1 1]);
    uistack(ax, 'bottom'); % Send the axes to the bottom layer
    img = imread('background.png'); % Replace with your image file
    imshow(img, 'Parent', ax);

    % Vytvorenie napisu v menu
    uicontrol('Style', 'text', 'String', 'Psik', ...
              'FontSize', 20, 'Position', [50, 240, 200, 40], ...
              'BackgroundColor', 'white', 'HorizontalAlignment', 'center');

    
 
    % Vytvorenie tlacitka na start Hry
    startButton = uicontrol('Style', 'pushbutton', 'String', 'Start Game', ...
                            'FontSize', 12, 'Position', [100, 175, 100, 50], ...
                            'Callback', @startGame);
    %tlacitko na skiny
    uicontrol('Style', 'pushbutton', 'String', 'Change Skin', ...
              'FontSize', 12, 'Position', [100, 120, 100, 50], ...
              'Callback', @(src, event) createSkinSelectionMenu());
    %zobrazenie pre pocet vyhier
    uicontrol('Style', 'text', 'String', sprintf('Wins: %d', numWins), ...
              'FontSize', 12, 'Position', [10, 120, 80, 40], ...
              'BackgroundColor', 'white', 'HorizontalAlignment', 'center');
    %Button/tlacitko ktore zobrazi herne pravidla
    uicontrol('Style', 'pushbutton', 'String', 'How to Play', ...
              'FontSize', 12, 'Position', [100, 25, 100, 50], ...
              'Callback', @showRules);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Pravidla pre hraca
function showRules(~, ~)
    % Vytvorenie okna na pravidla
    rulesFig = figure('Color', 'white', 'NumberTitle', 'off', 'MenuBar', 'none', ...
                      'Name', 'Game Rules', 'Position', [200, 200, 500, 300]);

    % Text Pravidel
    rulesText = {'Pravidlo 1: Zbieraj Bodiky Na Skore', ...
                 'Pravidlo 2: Po dosiahnuti x skore si vyhral', ...
                 'Pravidlo 3: Pozor na zelene bodiky ! Za kazdy je -1 score.', ...
                 'Pravidlo 3: Ak dosiahnes zaporne skore - prehral si.', ...
                 'Pohyb: Sipky na klavesnici', ...
                 'Skiny: Po vyhre, si mozes ist do obchodu kupit novy skin'};

    uicontrol(rulesFig, 'Style', 'text', 'String', rulesText, ...
              'FontSize', 12, 'Position', [10, 10, 480, 280], ...
              'HorizontalAlignment', 'left', 'BackgroundColor', 'white');
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function selectSkin(source, ~)
    global skins;
    global selectedSkin;

    skinNames = fieldnames(skins);
    selectedSkin = skinNames{source.Value}; 
 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function startGame(~, ~)
    % Zavretie start screenu
    close(gcf);

    % Zavolanie zaciatku hry
    startGameWindow();
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function startGameWindow()

%premenne vyuzivane v metode
global selectedSkin;
global score;
global scoreText;
global badPoint;
global moveDistance;
global audioPlayer;


% Vytvorenie hry - Inicializacia postavy a bodu
gameFig = figure('Color', 'white', 'KeyPressFcn', @keyPress, 'CloseRequestFcn', @closeGame);

axis([0 200 0 200]);
hold on;
%mriezka grafu
grid off;
axis off;
%zafarbenie hracej plochy
rectangle('Position', [0, 0, 200, 200], 'FaceColor', [0.8, 0.8, 0.8]); % Light gray color
scoreText = uicontrol('Style', 'text', 'String', sprintf('Score: %d', score), ...
                      'FontSize', 12, 'Position', [10, 180, 100, 20], ... 
                      'BackgroundColor', 'white');
%vyberatie defaultneho skinu, ak nie je ziadna selectnuty
  if isempty(selectedSkin)
        selectedSkin = 'default_skin.png'; 
    end
    
% Nacitanie obrazk us alpha channelom - kvoli PNGckam
[playerImage, ~, alpha] = imread(selectedSkin);

% Velkost hrdiny - potrebna aby sme nevysli mimo jeho povodnu velkost
heroSize = [16, 16];

% Zmenime velkost obrazku aby sedela velkosti hrdiny
playerImage = imresize(playerImage, heroSize);
alpha = imresize(alpha, heroSize);

% Zaciatocna pozicia hraca
playerPos = [45, 45]; 
% Zobrazenie obrazku na danych osach
playerHandle = imshow(playerImage, 'Parent', gca, 'InitialMagnification', 'fit');
set(playerHandle, 'AlphaData', alpha);

% Posun psika vzhladom na jeho poziciu
set(playerHandle, 'XData', [playerPos(1), playerPos(1) + heroSize(1)], ...
                  'YData', [playerPos(2), playerPos(2) + heroSize(2)]);


%hero = rectangle('Position', [45, 45, 10, 10], 'Curvature', [1, 1], 'FaceColor', 'blue');

% Bodiky "Granulky"
target = rectangle('Position', [randi([10, 90]), randi([10, 90]), 10, 10], 'Curvature', [1, 1], 'FaceColor', 'red');
score = 0;
badPoint = rectangle('Position', [randi([10, 90]), randi([10, 90]), 10, 10], 'Curvature', [1, 1], 'FaceColor', 'green');

%Pre ukoncenie hry ked mame dost bodikov

isGameOver = false;

[y, Fs] = audioread('music.wav');
audioPlayer = audioplayer(y, Fs);
play(audioPlayer);

%Pohyb psika
function keyPress(~, event)
    
    if ishandle(badPoint)
        badPos = get(badPoint, 'Position');
        
        % Nahodne zvolenie pohybu pre zly bodik
        directions = {'left', 'right', 'up', 'down'};
        moveDir = directions{randi(4)};
        
        % Update pozicia na zaklade smeru
        switch moveDir
            case 'left'
                badPos(1) = max(badPos(1) - moveDistance, 0);
            case 'right'
                badPos(1) = min(badPos(1) + moveDistance, 190); 
            case 'up'
                badPos(2) = min(badPos(2) + moveDistance, 190);
            case 'down'
                badPos(2) = max(badPos(2) - moveDistance, 0);
        end

        set(badPoint, 'Position', badPos);
    end
    % Ak hra sa skoncila, neodpoveda na dalsie klikanie sipiek
    if isGameOver
        return;
    end
    % Aktualna pozicia Psika
    xData = get(playerHandle, 'XData');
    yData = get(playerHandle, 'YData');

    % Presun psika sipkami
    switch event.Key
        case 'leftarrow'
            newX = max(xData(1) - 5, 0);
        case 'rightarrow'
            newX = min(xData(1) + 5, 190);
        case 'uparrow'
            newY = min(yData(1) - 5, 190);
        case 'downarrow'
            newY = max(yData(1) + 5, 0);
    end
    
    % Posunutie Psika
 if exist('newX', 'var')
        set(playerHandle, 'XData', [newX, newX + heroSize(1)]);
    end
    if exist('newY', 'var')
        set(playerHandle, 'YData', [newY, newY + heroSize(2)]);
    end

    
    % Pozeranie ci sa psik prekryva s bodikom - funkcia
    checkCollision();
end


function checkCollision()

    if ishandle(scoreText) % Kontroluje validitu text handlu
        set(scoreText, 'String', sprintf('Score: %d', score));
    end
    % Pozicia psika
    xData = get(playerHandle, 'XData');
    yData = get(playerHandle, 'YData');

    % Vypocitanie "boxu" psa
    dogPos = [xData(1), yData(1), heroSize(1), heroSize(2)];

    % Dostaneme poziciu granulky
    targetPos = get(target, 'Position');
    %Dostaneme poziciu "zleho" bodiku
    badPointPos = get(badPoint, 'Position');

    %skontroluje podmienku pre prehru
    if score < 0
        endGame(false);
    end
    %Stretnutie so zlym bodikom
   if isCollision(dogPos, badPointPos)
        score = score - 1; 
        if ishandle(scoreText) 
            set(scoreText, 'String', sprintf('Score: %d', score));
        end
        % Randomly move the bad point
        set(badPoint, 'Position', [randi([10, 190]), randi([10, 190]), 10, 10]);
    end

    % Pozeranie prekrytia/kolizie
    if isCollision(dogPos, targetPos)
        %Pridanie Skore Pri zobrati granulky
        score = score + 1;
        set(target, 'Position', [randi([10, 190]), randi([10, 190]), 10, 10]);

        %Podmienka pri ktorej sa ukonci hra - Hrac vyhra
        if score >= 10
            endGame(true);
        end
        %Podmienka pri ktorej sa ukonci hra - Hrac prehra

    end
end

function result = isCollision(rect1, rect2)
    % Rozhodovanie, ci sa prekryvaju
    result = rect1(1) < rect2(1) + rect2(3) && ...
             rect1(1) + rect1(3) > rect2(1) && ...
             rect1(2) < rect2(2) + rect2(4) && ...
             rect1(2) + rect1(4) > rect2(2);
end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function resetGame(source, ~)
    % Vypnutie obrazovku Koniec Hry
    close(ancestor(source, 'figure'));

    % Vycistenie premennych
    global score;
    global isGameOver; 
    global playerHandle;

    score = 0;
    isGameOver = false;

    % V pripade, ze mame ulozeny hracov skin
    if ~isempty(playerHandle) && ishandle(playerHandle)
        delete(playerHandle);
    end

    % Znova zavolame start menu
    createStartScreen();
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Vytvori konecne "okno"


function endGame(won)
    global audioPlayer;
    global score;
    global gameFig;
    global isGameOver;
    if isvalid(audioPlayer)
        stop(audioPlayer);
    end
    isGameOver = true;
    if won
        updateWins();
    end


    % Clear the game area
    cla;

    % Display appropriate message based on win or lose
    if won
        message = sprintf('Congratulations! Your score: %d', score);
        color = 'green';
    else
        message = sprintf('Game Over. Your score: %d', score);
        color = 'red';
    end

    text(50, 50, message, ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'middle', ...
         'FontSize', 14, ...
         'Color', color);

    % Disable further key presses
    set(gameFig, 'KeyPressFcn', '');

    % Set the axes limits
    xlim([0 100]);
    ylim([0 100]);

    % Add "Play Again" button to the screen
    uicontrol('Style', 'pushbutton', 'String', 'Play Again', ...
              'FontSize', 12, 'Position', [175, 20, 200, 140], ...
              'Callback', @resetGame);
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Funkcia na vypnutie hudby v pripade zavretia okna
function closeGame(src, ~)
    global audioPlayer;

    % Stop the audio
    if isvalid(audioPlayer)
        stop(audioPlayer);
    end

    % Delete the game figure
    delete(src);
end
